﻿using System;
using System.Threading;
using Swed32;

namespace OutlastGodmode
{
    class Program
    {
        static void Main(string[] args)
        {

            bool.TryParse(args[0],out bool value);
            
            Swed swed = new Swed("OLGame");

            IntPtr moduleBase = swed.GetModuleBase("OLGame.exe");

            if (value)
            {
                swed.Nop(moduleBase + 0xC76724, 8);
            }
            else
            {
                swed.WriteBytes(moduleBase + 0xC76724, new byte[] { 0xF3, 0x0F, 0x11, 0x8D, 0x44, 0x2E, 0x00, 0x00 });
            }
           
        }
    }
}
