﻿using Swed32;
using System.Diagnostics;
using System.Runtime.CompilerServices;


public class EnemyToggle
{
    public static void Main(String[] args)
    {
        bool toggle = bool.Parse(args[0]);

        Swed swed = new Swed("OLGame");

        var proc = Process.GetProcessesByName("OLGame");


        IntPtr moduleBase = swed.GetModuleBase("OLGame.exe");
        IntPtr enemyY = swed.ReadPointer(moduleBase, 0x178E804, 0x54, 0x4C)      + 0x5C;
        IntPtr enemyX = swed.ReadPointer(moduleBase, 0x178E804, 0x54, 0x4C,0xDC) + 0x54;
        IntPtr enemyZ = swed.ReadPointer(moduleBase, 0x178E804, 0x50, 0x4C,0xDC) + 0x58;
        float enemyYValue = swed.ReadFloat(enemyY);
        float enemyXValue = swed.ReadFloat(enemyX);
        float enemyZValue = swed.ReadFloat(enemyZ);

        while (true)
        {

            if (toggle)
            {
                swed.WriteFloat(enemyZ, enemyZValue);
                swed.WriteFloat(enemyY, enemyYValue);
                swed.WriteFloat(enemyX, enemyXValue);
            }


            if (proc.Length == 0)
            {
                Process.GetCurrentProcess().Kill();
            }

            System.Threading.Thread.Sleep(25);
        }

    }
}
