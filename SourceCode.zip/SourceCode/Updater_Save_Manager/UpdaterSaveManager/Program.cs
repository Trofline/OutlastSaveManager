﻿using System;
using System.IO;
using System.IO.Compression;
using System.Diagnostics;
using System.Threading;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Updater started...");

        if (args.Length < 2)
        {
            Console.WriteLine("Usage: Updater.exe <zipPath> <targetExe>");
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
            return;
        }

        string zipPath = args[0];
        string targetExe = args[1];
        if (targetExe == "RunMe.exe" )
        {
            targetExe = Path.Combine("SaveManager","OutlastSaveManager.exe");
        }
        if (targetExe == "RunMe")
        {
            targetExe = Path.Combine("SaveManager", "OutlastSaveManager");
        }
        string targetDir = Path.GetDirectoryName(targetExe);

        // Prüfen, ob OLGame und Binaries im selben Verzeichnis wie das Updater-Programm existieren
        string programDir = AppDomain.CurrentDomain.BaseDirectory;
        string olGamePath = Path.Combine(programDir, "OLGame");
        string binariesPath = Path.Combine(programDir, "Binaries");
        string saveManagerPath = targetDir; // Standard-Ziel

        if (Directory.Exists(olGamePath) && Directory.Exists(binariesPath))
        {
            saveManagerPath = Path.Combine(programDir, "SaveManager");
            if (!Directory.Exists(saveManagerPath))
                Directory.CreateDirectory(saveManagerPath);

            Console.WriteLine("OLGame und Binaries gefunden. Updates werden in SaveManager installiert.");
        }
        else
        {
            Console.WriteLine("OLGame oder Binaries nicht gefunden. Updates werden im Standardverzeichnis installiert.");
        }

        Console.WriteLine($"ZIP Path: {zipPath}");
        Console.WriteLine($"Target EXE: {targetExe}");
        Console.WriteLine("Waiting for target program to exit...");

        // Kill all running target processes
        foreach (var process in Process.GetProcessesByName("OLGame"))
        {
            try
            {
                process.Kill();
                process.WaitForExit();
                Console.WriteLine($"Killed process: {process.ProcessName}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Could not kill process {process.ProcessName}: {ex.Message}");
            }
        }
        foreach (var process in Process.GetProcessesByName("hook"))
        {
            try
            {
                process.Kill();
                process.WaitForExit();
                Console.WriteLine($"Killed process: {process.ProcessName}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Could not kill process {process.ProcessName}: {ex.Message}");
            }
        }
        foreach (var process in Process.GetProcessesByName("BetterOutlastLauncher"))
        {
            try
            {
                process.Kill();
                process.WaitForExit();
                Console.WriteLine($"Killed process: {process.ProcessName}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Could not kill process {process.ProcessName}: {ex.Message}");
            }
        }
        foreach (var process in Process.GetProcessesByName("OutlastSaveManager"))
        {
            try
            {
                process.Kill();
                process.WaitForExit();
                Console.WriteLine($"Killed process: {process.ProcessName}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Could not kill process {process.ProcessName}: {ex.Message}");
            }
        }

        // Small pause to make sure the program has exited
        Thread.Sleep(1000);

        try
        {
            using (ZipArchive archive = ZipFile.OpenRead(zipPath))
            {
                foreach (var entry in archive.Entries)
                {
                    string destinationPath = Path.Combine(saveManagerPath, entry.FullName.Replace('/', Path.DirectorySeparatorChar));

                    // Ensure all directories exist
                    string directory = Path.GetDirectoryName(destinationPath);
                    if (!Directory.Exists(directory))
                        Directory.CreateDirectory(directory);

                    // Extract only files
                    if (!string.IsNullOrEmpty(entry.Name))
                    {
                        entry.ExtractToFile(destinationPath, overwrite: true);
                        Console.WriteLine($"Extracted: {entry.FullName}");
                    }
                }
            }

            // Delete the ZIP
            if (File.Exists(zipPath))
            {
                File.Delete(zipPath);
                Console.WriteLine("Deleted update ZIP file.");
            }

            // Restart target program
            Console.WriteLine("Restarting target program...");
            Process.Start(new ProcessStartInfo
            {
                FileName = targetExe,
                UseShellExecute = true,
                Arguments = "Vanilla",
                WindowStyle = ProcessWindowStyle.Normal
            });

            Console.WriteLine("Update finished successfully.\nDeleting old files...");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error during update: " + ex.Message);
        }

        if (Directory.Exists(olGamePath) && Directory.Exists(binariesPath))
        {
            var curDir = Directory.GetCurrentDirectory();
            try { File.Delete(Path.Combine(curDir, "OutlastSaveManager.dll.config")); } catch { }
            try { File.Delete(Path.Combine(curDir, "OutlastSaveManager.exe")); } catch { }
            try { File.Delete(Path.Combine(curDir, "OutlastSaveManager.pdb")); } catch { }
            try { File.Delete(Path.Combine(curDir, "README.md")); } catch { }
            try { File.Delete(Path.Combine(curDir, "Microsoft.Web.WebView2.Core.xml")); } catch { }
            try { File.Delete(Path.Combine(curDir, "Microsoft.Web.WebView2.WinForms.xml")); } catch { }
            try { File.Delete(Path.Combine(curDir, "Microsoft.Web.WebView2.Wpf.xml")); } catch { }
            try { File.Delete(Path.Combine(curDir, "WebView2Loader.dll")); } catch { }
            try { Directory.Delete(Path.Combine(curDir, "SaveManager-Mods"),true); } catch { }
            try { Directory.Delete(Path.Combine(curDir, "SaveData"),true); } catch { }
            try { Directory.Delete(Path.Combine(curDir, "runtimes"),true); } catch { }
            try { Directory.Move(Path.Combine(curDir, "Boot"), Path.Combine(curDir, "SaveManager", "Boot")); } catch { }
            try { Directory.Delete(Path.Combine(curDir, "Boot"), true); } catch { }
        }

        Console.WriteLine("Finished");
        Console.WriteLine("Updater closing...");




        Thread.Sleep(4000);
    }
}
