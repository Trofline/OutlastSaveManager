﻿using Swed32;
using System;
using System.ComponentModel;
using System.Threading;

class Program
{
    public static void Main(string[] args)
    {
        float newHitboxValue = float.Parse(args[0]);

        Swed swed = new Swed("OLGame");

        IntPtr moduleBase = swed.GetModuleBase("OLGame.exe");
        IntPtr hitboxAddressToNop = moduleBase + 0x218AE4;

        IntPtr hitboxAddressToWrite = swed.ReadPointer(moduleBase, 0x178E804, 0x28, 0xFC, 0x28, 0x3C,0x4) + 0x1DC;
        byte[] originalBytes = new byte[] { 0xF3, 0x0F, 0x11 ,0x81 ,0xDC ,0x01 ,0x00 ,0x00 };

        if (newHitboxValue == 30f)
        {
            swed.WriteFloat(hitboxAddressToWrite, 30f);
            swed.WriteBytes(hitboxAddressToNop, originalBytes);
            swed.WriteFloat(hitboxAddressToWrite, 30f);
        }
        else
        {
            swed.Nop(hitboxAddressToNop, 8);
            swed.WriteFloat(hitboxAddressToWrite, newHitboxValue);

        }

    }
}
