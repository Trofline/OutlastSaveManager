﻿using Swed32;

public class Program
{
    public static void Main(String[] args)
    {
        string command = args[0].ToLower();

        Swed swed = new Swed("OLGame");

        IntPtr moduleBase = swed.GetModuleBase("OLGame.exe");


        byte[] originalBytes = new byte[] { 0xF3, 0x0F, 0x11, 0x81, 0xDC, 0x01, 0x00, 0x00 };

        IntPtr hitboxAddressToNop = moduleBase + 0x218AE4;

        if (args[0] == "nop")
        {
            swed.Nop(hitboxAddressToNop, 8);
        }
        else if (args[0] == "unnop")
        {
            swed.WriteBytes(hitboxAddressToNop, originalBytes);
        }
    }
}