﻿using Swed64;

Swed swed = new Swed("OLGame");

IntPtr moduleBase = swed.GetModuleBase("OLGame.exe");

IntPtr freeCamAddrFirst = swed.ReadPointer(moduleBase, 0x2020F38, 0x20, 0x1C, 0x4C0, 0x24C) + 0xD50;
IntPtr freeCamAddrMiddle = swed.ReadPointer(moduleBase, 0x2020F38, 0x20, 0x1C, 0x4C0, 0x24C) + 0xD54;
IntPtr freeCamAddrLast = swed.ReadPointer(moduleBase, 0x2020F38, 0x20, 0x1C, 0x4C0, 0x24C) + 0xD58;


IntPtr milesFirst = swed.ReadPointer(moduleBase, 0x20093A0, 0x48, 0x40, 0x114) + 0x80;
IntPtr milesMiddle = swed.ReadPointer(moduleBase, 0x20093A0, 0x48, 0x40, 0x114) + 0x84;
IntPtr milesLast = swed.ReadPointer(moduleBase, 0x20093A0, 0x48, 0x40, 0x114) + 0x88;



swed.WriteFloat(milesFirst, swed.ReadFloat(freeCamAddrFirst));
swed.WriteFloat(milesMiddle, swed.ReadFloat(freeCamAddrMiddle));
swed.WriteFloat(milesLast, swed.ReadFloat(freeCamAddrLast)-130f);