﻿using Swed32;

Swed swed = new Swed("OLGame");

IntPtr moduleBase = swed.GetModuleBase("OLGame.exe");

IntPtr freeCamAddrFirst = swed.ReadPointer(moduleBase, 0x178E804, 0x0, 0x28, 0x1D4, 0x9C) + 0xB34;
IntPtr freeCamAddrMiddle = swed.ReadPointer(moduleBase, 0x178E804, 0x0, 0x28, 0x1D4, 0x9C) + 0xB38;
IntPtr freeCamAddrLast = swed.ReadPointer(moduleBase, 0x178E804,0x0,0x28,0x1D4,0x9C) + 0xB3C;

IntPtr milesFirst = swed.ReadPointer(moduleBase, 0x0178E804, 0x20, 0x28, 0xDC) + 0x54;
IntPtr milesMiddle = swed.ReadPointer(moduleBase, 0x0178E804, 0x20, 0x28, 0xDC) + 0x58;
IntPtr milesLast = swed.ReadPointer(moduleBase, 0x0178E804, 0x20, 0x28, 0xDC) + 0x5C;


swed.WriteFloat(milesFirst,swed.ReadFloat(freeCamAddrFirst));
swed.WriteFloat(milesMiddle, swed.ReadFloat(freeCamAddrMiddle));
swed.WriteFloat(milesLast, swed.ReadFloat(freeCamAddrLast)-130f);