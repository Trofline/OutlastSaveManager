﻿using Swed64;
using System;
using System.ComponentModel;
using System.Threading;

class Program
{
    public static void Main(string[] args)
    {
        float newHitboxValue = float.Parse(args[0]);

        Swed swed = new Swed("OLGame");

        IntPtr moduleBase = swed.GetModuleBase("OLGame.exe");
        IntPtr hitboxAddressToNop = moduleBase + 0x252F08;
        IntPtr hitboxAddressToWrite = swed.ReadPointer(moduleBase, 0x20093A0,0x38,0x40,0x44C) + 0x22C;
        byte[] originalBytes = new byte[] { 0xF3, 0x0F, 0x11, 0x89, 0x2C, 0x02, 0x00, 0x00 };

        if (newHitboxValue == 30f)
        {
            swed.WriteFloat(hitboxAddressToWrite, 30f);
            swed.WriteBytes(hitboxAddressToNop, originalBytes);
            swed.WriteFloat(hitboxAddressToWrite, 30f);
        }
        else
        {
            swed.Nop(hitboxAddressToNop, 8);
            swed.WriteFloat(hitboxAddressToWrite, newHitboxValue);

        }
    }
}
