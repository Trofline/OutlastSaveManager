﻿using System;
using System.Threading;
using Swed64;

namespace OutlastGodmode
{
    class Program
    {
        static void Main(string[] args)
        {

            bool.TryParse(args[0], out bool value);

            Swed swed = new Swed("OLGame");

            IntPtr moduleBase = swed.GetModuleBase("OLGame.exe");

            if (value)
            {
                swed.Nop(moduleBase + 0xD8A1E5, 8);
            }
            else
            {
                swed.WriteBytes(moduleBase + 0xC76724, new byte[] { 0xF3, 0x0F, 0x11, 0x8E, 0x68, 0x31, 0x00, 0x00 });
            }

        }
    }
}
