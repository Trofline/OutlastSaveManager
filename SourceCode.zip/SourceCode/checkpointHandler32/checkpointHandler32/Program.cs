﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Swed32;

class Program
{
    // Hotkey IDs
    private const int HOTKEY_F1 = 1;
    private const int HOTKEY_F2 = 2;
    private const int HOTKEY_F3 = 3;
    private const int HOTKEY_F4 = 4;
    private const int HOTKEY_CTRL_F1 = 5;
    private const int HOTKEY_CTRL_F2 = 6;
    private const int HOTKEY_CTRL_F3 = 7;
    private const int HOTKEY_CTRL_F4 = 8;

    [DllImport("user32.dll")]
    private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

    [DllImport("user32.dll")]
    private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

    const uint MOD_CONTROL = 0x2;
    const uint VK_F1 = 0x70;
    const uint VK_F2 = 0x71;
    const uint VK_F3 = 0x72;
    const uint VK_F4 = 0x73;

    [StructLayout(LayoutKind.Sequential)]
    private struct MSG
    {
        public IntPtr hwnd;
        public uint message;
        public IntPtr wParam;
        public IntPtr lParam;
        public uint time;
        public System.Drawing.Point pt;
    }

    [DllImport("user32.dll")]
    private static extern int GetMessage(out MSG lpMsg, IntPtr hWnd, uint wMsgFilterMin, uint wMsgFilterMax);

    static void Main()
    {
        Swed swed = new Swed("OLGame");

        // Speicherplätze für 4 Teleport-Slots
        float?[,] savedCoords = new float?[4, 3];

        // Hotkeys registrieren
        RegisterHotKey(IntPtr.Zero, HOTKEY_F1, 0, VK_F1);
        RegisterHotKey(IntPtr.Zero, HOTKEY_F2, 0, VK_F2);
        RegisterHotKey(IntPtr.Zero, HOTKEY_F3, 0, VK_F3);
        RegisterHotKey(IntPtr.Zero, HOTKEY_F4, 0, VK_F4);
        RegisterHotKey(IntPtr.Zero, HOTKEY_CTRL_F1, MOD_CONTROL, VK_F1);
        RegisterHotKey(IntPtr.Zero, HOTKEY_CTRL_F2, MOD_CONTROL, VK_F2);
        RegisterHotKey(IntPtr.Zero, HOTKEY_CTRL_F3, MOD_CONTROL, VK_F3);
        RegisterHotKey(IntPtr.Zero, HOTKEY_CTRL_F4, MOD_CONTROL, VK_F4);

        Console.WriteLine("Running... Ctrl+F1-F4 = Save pos, F1-F4 = Load pos\nCreated by Trofline");

        // Message Loop
        MSG msg;
        while (true)
        {
            // Wenn Prozess nicht mehr läuft → beenden
            if (Process.GetProcessesByName("OLGame").Length == 0)
            {
                Console.WriteLine("OLGame.exe not running, closing...");
                break;
            }

            if (GetMessage(out msg, IntPtr.Zero, 0, 0) != 0)
            {
                int hotkeyId = msg.wParam.ToInt32();

                switch (hotkeyId)
                {
                    case HOTKEY_CTRL_F1:
                        SavePos(swed, savedCoords, 0);
                        break;
                    case HOTKEY_CTRL_F2:
                        SavePos(swed, savedCoords, 1);
                        break;
                    case HOTKEY_CTRL_F3:
                        SavePos(swed, savedCoords, 2);
                        break;
                    case HOTKEY_CTRL_F4:
                        SavePos(swed, savedCoords, 3);
                        break;
                    case HOTKEY_F1:
                        LoadPos(swed, savedCoords, 0);
                        break;
                    case HOTKEY_F2:
                        LoadPos(swed, savedCoords, 1);
                        break;
                    case HOTKEY_F3:
                        LoadPos(swed, savedCoords, 2);
                        break;
                    case HOTKEY_F4:
                        LoadPos(swed, savedCoords, 3);
                        break;
                }
            }
        }

        // Hotkeys deregistrieren
        UnregisterHotKey(IntPtr.Zero, HOTKEY_F1);
        UnregisterHotKey(IntPtr.Zero, HOTKEY_F2);
        UnregisterHotKey(IntPtr.Zero, HOTKEY_F3);
        UnregisterHotKey(IntPtr.Zero, HOTKEY_F4);
        UnregisterHotKey(IntPtr.Zero, HOTKEY_CTRL_F1);
        UnregisterHotKey(IntPtr.Zero, HOTKEY_CTRL_F2);
        UnregisterHotKey(IntPtr.Zero, HOTKEY_CTRL_F3);
        UnregisterHotKey(IntPtr.Zero, HOTKEY_CTRL_F4);
    }

    static void SavePos(Swed swed, float?[,] store, int slot)
    {
        IntPtr moduleBase = swed.GetModuleBase("OLGame.exe");

        // Pointer jedes Mal frisch auflösen
        IntPtr milesFirst = swed.ReadPointer(moduleBase, 0x0178E804, 0x20, 0x28, 0xDC) + 0x54;
        IntPtr milesMiddle = swed.ReadPointer(moduleBase, 0x0178E804, 0x20, 0x28, 0xDC) + 0x58;
        IntPtr milesLast = swed.ReadPointer(moduleBase, 0x0178E804, 0x20, 0x28, 0xDC) + 0x5C;

        float x = swed.ReadFloat(milesFirst);
        float y = swed.ReadFloat(milesMiddle);
        float z = swed.ReadFloat(milesLast);

        store[slot, 0] = x;
        store[slot, 1] = y;
        store[slot, 2] = z;

        Console.WriteLine($"[SAVED] Slot {slot + 1}: {x}, {y}, {z}");
    }

    static void LoadPos(Swed swed, float?[,] store, int slot)
    {
        if (!store[slot, 0].HasValue)
        {
            Console.WriteLine($"[EMPTY] Slot {slot + 1} has no saved coords!");
            return;
        }

        IntPtr moduleBase = swed.GetModuleBase("OLGame.exe");

        // Pointer jedes Mal frisch auflösen
        IntPtr milesFirst = swed.ReadPointer(moduleBase, 0x0178E804, 0x20, 0x28, 0xDC) + 0x54;
        IntPtr milesMiddle = swed.ReadPointer(moduleBase, 0x0178E804, 0x20, 0x28, 0xDC) + 0x58;
        IntPtr milesLast = swed.ReadPointer(moduleBase, 0x0178E804, 0x20, 0x28, 0xDC) + 0x5C;

        IntPtr milesSpeedFirst = swed.ReadPointer(moduleBase, 0x178E7F8, 0x8, 0x9C, 0x4CC) + 0x13C;
        IntPtr milesSpeedMiddle = swed.ReadPointer(moduleBase, 0x2020F38, 0xA4C, 0x44C, 0x40) + 0x140;
        IntPtr milesSpeedLast = swed.ReadPointer(moduleBase, 0x2020F38, 0xA4C, 0x44C, 0x40) + 0x144;

        //nop damage
        swed.Nop(moduleBase + 0xC76724, 8);

        // Koordinaten schreiben
        swed.WriteFloat(milesFirst, store[slot, 0].Value);
        swed.WriteFloat(milesMiddle, store[slot, 1].Value);
        swed.WriteFloat(milesLast, store[slot, 2].Value);

        // Geschwindigkeit zurücksetzen
        swed.WriteFloat(milesSpeedFirst, 0f);
        swed.WriteFloat(milesSpeedMiddle, 0f);
        swed.WriteFloat(milesSpeedLast, 0f);

        //unnop damage
        swed.WriteBytes(moduleBase + 0xC76724, new byte[] { 0xF3, 0x0F, 0x11, 0x8D, 0x44, 0x2E, 0x00, 0x00 });

        Console.WriteLine($"[LOADED] Slot {slot + 1} (Velocity reset to 0)");
    }
}
