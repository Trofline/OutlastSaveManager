﻿using Swed32;
using System;

class Program
{
    static void Main(string[] args)
    {

        if (args.Length == 0)
        {
            Console.WriteLine("Wrong arguments");
            return;
        }

        // Argument als bool parsen
        if (!bool.TryParse(args[0], out bool activate))
        {
            Console.WriteLine("Argument exception");
            return;
        }

        try
        {
            Swed swed = new Swed("OLGame");

            IntPtr moduleBase = swed.GetModuleBase("OLGame.exe");
            IntPtr cameraAddress = swed.ReadPointer(moduleBase, 0xC4AC86);

            float cam = swed.ReadFloat(cameraAddress);

            if (activate)
            {
                swed.Nop(moduleBase, 0xC4AC86, 8);

            }
            else
            {

                // Hier musst du die originalen Bytes wiederherstellen
                // Beispiel: wenn du vorher 8 Bytes ersetzt hast
                byte[] originalBytes = { 0xF3, 0x0F, 0x11, 0x86, 0x84, 0x2E, 0x00, 0x00 };
                swed.WriteBytes(moduleBase, 0xC4AC86, originalBytes);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Fehler: " + ex.Message);
        }
    }
}
