﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net;

namespace SimpleInstaller
{
    class Program
    {
        static void Main(string[] args)
        {
            string downloadUrl = "https://github.com/Trofline/Tools/releases/download/SaveManager/OutlastSaveManager.zip";
            string processName = "OLGame"; // Outlast process

            try
            {
                // --- Check process ---
                Process[] procs = Process.GetProcessesByName(processName);
                if (procs.Length == 0)
                {
                    Console.WriteLine($"Outlast ('{processName}') is not running.\nPlease start the game before running the installer/uninstaller again.");
                    Console.ReadKey();
                    return;
                }

                Process targetProcess = procs[0];
                string exeFolder = Path.GetDirectoryName(targetProcess.MainModule.FileName);

                // --- Adjust root folder if needed ---
                // Wenn OLGame.exe z.B. in "Binaries\Win64" liegt, zwei Ebenen hoch gehen:
                string rootFolder = Directory.GetParent(Directory.GetParent(exeFolder).FullName).FullName;
                string gameFolder = rootFolder;
                Console.WriteLine("Do you want to install or uninstall the game?\n[I] - Install\n[U] - Uninstall\n[E] - Exit\n\n");
               redo:
               
               ConsoleKeyInfo key = Console.ReadKey(true);
                
            

                if (key.Key == ConsoleKey.I)
                {
                    Console.WriteLine("Preparing");
                    // --- Download ZIP directly to root folder ---
                    if (!Directory.Exists(Path.Combine(rootFolder,"SaveManager")))
                    {
                        Directory.CreateDirectory(Path.Combine(rootFolder, "SaveManager"));
                    }
                    Console.WriteLine("Installing...");

                    string zipPath = Path.Combine(rootFolder,"SaveManager", "OutlastSaveManager.zip");
                    using (WebClient wc = new WebClient())
                    {
                        wc.DownloadFile(downloadUrl, zipPath);
                    }
                    Console.WriteLine("Extracting SaveManager");

                    // --- Extract ZIP to root folder ---
                    ZipFile.ExtractToDirectory(zipPath, Path.Combine(rootFolder,"SaveManager"), true);
                    Console.WriteLine("SaveManager installed successfully!\nMake sure to definitly read the README.md in the outlast root folder!\nYes, actually read them, atleast the first and most important rows\nPress any key to close the launcher, just make sure to read the readme please...");

                    // --- Delete ZIP after extraction ---
                    File.Delete(zipPath);

                    try
                    {
                        foreach (var process in Process.GetProcessesByName(processName))
                        {
                            process.Kill();
                            process.WaitForExit();
                        }

                        
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error: {ex.Message}\n\nJust run the OutlastSaveManager.exe in the Outlast/SaveManager folder,\ngo one folder back in your explorer and run the shortcut");
                    }

                    if (!Directory.Exists(Path.Combine(rootFolder,"SaveManager","Boot")))
                    {
                        Directory.CreateDirectory(Path.Combine(rootFolder, "SaveManager", "Boot"));
                    }

                    foreach (var item in procs)
                    {
                        item.Kill();
                        item.WaitForExit();
                    }
                    
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = Path.Combine(rootFolder, "SaveManager", "OutlastSaveManager.exe"),
                        WorkingDirectory = Path.Combine(rootFolder,"SaveManager"),
                        Arguments = "Vanilla"
                    });

                }
                else if (key.Key == ConsoleKey.U)
                {
                    Console.WriteLine("Uninstalling...");

                    rootFolder = Path.Combine(rootFolder, "SaveManager");

                    foreach (var item in procs)
                    {
                        item.Kill();
                        item.WaitForExit();
                    }
                    try { Directory.Delete(rootFolder, true); } catch { }
                    try { File.Delete(Path.Combine(gameFolder, "Vanilla.lnk")); } catch { }
                    try { File.Delete(Path.Combine(gameFolder, "AllDoorsUnlocked.lnk")); } catch { }
                    try { File.Delete(Path.Combine(gameFolder, "Macca%.lnk")); } catch { }
                    try { File.Delete(Path.Combine(gameFolder, "SaveManager.lnk")); } catch { }
                    try { File.Delete(Path.Combine(gameFolder, "SuperJump.lnk")); } catch { }
                    try { File.Delete(Path.Combine(gameFolder, "RunWithOtherProgram.bat")); } catch { }


                }
                else if (key.Key == ConsoleKey.E)
                {
                    Console.WriteLine("Exiting...");
                    Process.GetCurrentProcess().Kill();
                }
                else
                {
                    Console.WriteLine("Please choose");
                    goto redo;
                }


                 
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
                Console.WriteLine("If it can't be fixed, please do it manualy\nRead the readme on github how to");
            }

            Console.WriteLine("Done");
            Thread.Sleep(3000);
        }
    }
}
