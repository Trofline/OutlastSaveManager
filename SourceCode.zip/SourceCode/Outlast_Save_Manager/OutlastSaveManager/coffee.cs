﻿using OutlastSaveManager.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OutlastSaveManager
{
    public partial class coffee : Form
    {
        public coffee()
        {
            InitializeComponent();
            this.Icon = Resources.logo;
        }

        private void coffee_Load(object sender, EventArgs e)
        {

        }
    }
}
