### **❗❗❗ IMPORTANT❗❗❗**

 
> -  To install the program, make a directory named `SaveManager` in the outlast roor directory and drag and drop everything in there.
>	 Now start `OutlastSaveManager.exe` and it will create some folders & files first of, then in the outlast root directory there should be shortcuts to use
> -  SaveManager has a `RunWithOtherProgram.bat` file, which you can use to start other tools together with mine. You just need to right click, edit with editor
>  	 and change then copy&paste the path to your other tool inside of there, you will see where exactly. It will then start your selected tool, and once outlast boots up it starts Saveanager.
>	 Make sure to create a shortcut for runwithotherprogram.bat, so you dont move the batch file anywhere
> -  SaveManager will only work without Steam!
> -  Make sure to check Hotkeys in the settings, there are some useful ones and features you can only use trough hotkeys
> -  You can edit the Game-Hours by clicking on the label!
> -  You can disable these info icons in the settings
> -  Checking the Parent-Box in the TreeView (for example SaveData), checks of course the Child-Box's too
> -  If it will sometime be not visible in the taskbar, press` kombination to toggle window` or whatever you have bound it to, to bring it up again
>  	 this mostly happens when you boot it with `StartMinimized`, or press win key while its booting up
> -  To boot (if outlast is already open) just open `SaveManager`, otherwise there will be automaticaly
>  	 shortcuts in the outlast root folder created for you, where you can then start with mods directly or just vanilla...
> -  Inside of the folder `Boot`, you can put shortcuts of programs/websites/folder... in. The programm will run everything inside of there; Go to settings and open it up there
> -  Make sure to have the mod `Borderless Window Mod` in the settings enabled, to avoid tabbing out from [Toggle Window]
> -  Make sure NOT to rename ANYTHING from the SaveManager, or it might not work anymore
> -  Some of the mods you will have to re-enable after s+q (looking out for a fix in the future)
> -  If you have External Mods enabled, and booted the Manager together with another program, some mods could have a conflict with the other tool
> -  Some mods/keybinds will only work with Internal Mods, so have External Mods disabled!
> -  You can hover over almost everything to see what its doing
> -  Make keybinds for SpeedrunHelper (btw. it keeps the checkpoints after closing the game)

### Changelog

> -  Set and Load Speedrun Start is to load a checkpoint and set a checkpoint (the start of the category youre speedrunning for example. It deletes not neccessary save files for you and loads you into the checkpoint)
> -  Reset Collactibles (resets the documents and records, so you dont have to reload)
> -  Added Reset World (resets the world state so you dont have to reload,including interactables such as doors, boxes... and most of the cutscenes etc..) 
> -  GameplayMarkers (shows markers, such as spots where you can vault, climb, squeeze, etc etc)
> -  PlayerInfo (shows the player informations such as velocity, coordinates and camera viewment)
> -  This a hella big update, I tested everything I could possibly think of, but if you find any bugs please report them in the help section
> -  Most of the new features are only useable via Hotkeys.
> -  If you got more ideas, just text me on discord


### 📂 Loaded Checkpoints

Displays all currently loaded checkpoints.


### 🗃️ Checkpoint Pod

Shows all available checkpoints that you can load.


### 🖥️ Console (Bottom Right)

Displays status messages:

**✅ Green = Successful

⚠️ Yellow = Warning

❌ Red = Error**


### ➕ Set Checkpoint

Select checkpoints from the Checkpoint Pod to add to your loaded checkpoints.


### ➖ Remove Checkpoint

Select checkpoints from Loaded Checkpoints to remove.

If you try to remove read-only checkpoints together with normal ones, the tool will ask for confirmation.


### 🔒 Set Read-Only

Mark selected Loaded Checkpoints as read-only so they cannot be deleted accidentally.

By clicking Set Read-Only, you can add & set Checkpoints from the Pod too


### 🗑️ Remove Read-Only

Select read-only checkpoints you want to remove.

If  read-only checkpoints and non-read-only checkpoints are checked, it will ask you.


### ❓ Help

Opens a help window with 4 buttons.

Hover over the buttons to see what they do.


### 🎖️ Credits

Displays credits in the console.


### ☕ Buy Me a Coffee

Shows a PayPal QR code if you’d like to support my work.

Writing this tool took approximately 20–28 hours — even €1 for a coffee is highly appreciated. 😊


### ⚙️ Settings

Adjust various tool settings.

Hover over options to see their effects.


### 🥚 Easter Egg

A hidden Easter Egg is somewhere in the application — can you find it? 🔍


<img width="1919" height="1079" alt="image" src="https://github.com/user-attachments/assets/e6825890-4fba-4038-8934-b66876724779" />