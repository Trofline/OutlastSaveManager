﻿namespace OutlastSaveManager
{
    partial class mods
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            toolTip1 = new ToolTip(components);
            panel1 = new Panel();
            panel3 = new Panel();
            saveCheckpointSave = new MaterialSkin.Controls.MaterialComboBox();
            savePresetPreset = new MaterialSkin.Controls.MaterialComboBox();
            loadCheckpointSave = new MaterialSkin.Controls.MaterialComboBox();
            loadPresetPreset = new MaterialSkin.Controls.MaterialComboBox();
            materialButton6 = new MaterialSkin.Controls.MaterialButton();
            saveCheckpoint = new MaterialSkin.Controls.MaterialButton();
            loadCheckpoint = new MaterialSkin.Controls.MaterialButton();
            materialButton5 = new MaterialSkin.Controls.MaterialButton();
            panel4 = new Panel();
            materialButton11 = new MaterialSkin.Controls.MaterialButton();
            materialButton10 = new MaterialSkin.Controls.MaterialButton();
            materialButton9 = new MaterialSkin.Controls.MaterialButton();
            panel6 = new Panel();
            materialButton25 = new MaterialSkin.Controls.MaterialButton();
            materialButton23 = new MaterialSkin.Controls.MaterialButton();
            materialButton30 = new MaterialSkin.Controls.MaterialButton();
            materialButton31 = new MaterialSkin.Controls.MaterialButton();
            materialButton33 = new MaterialSkin.Controls.MaterialButton();
            materialButton34 = new MaterialSkin.Controls.MaterialButton();
            materialButton35 = new MaterialSkin.Controls.MaterialButton();
            materialButton37 = new MaterialSkin.Controls.MaterialButton();
            materialButton38 = new MaterialSkin.Controls.MaterialButton();
            materialButton39 = new MaterialSkin.Controls.MaterialButton();
            materialButton40 = new MaterialSkin.Controls.MaterialButton();
            materialButton41 = new MaterialSkin.Controls.MaterialButton();
            materialButton42 = new MaterialSkin.Controls.MaterialButton();
            materialButton43 = new MaterialSkin.Controls.MaterialButton();
            panel5 = new Panel();
            materialButton19 = new MaterialSkin.Controls.MaterialButton();
            materialButton29 = new MaterialSkin.Controls.MaterialButton();
            materialButton26 = new MaterialSkin.Controls.MaterialButton();
            materialButton12 = new MaterialSkin.Controls.MaterialButton();
            materialButton18 = new MaterialSkin.Controls.MaterialButton();
            materialButton24 = new MaterialSkin.Controls.MaterialButton();
            materialButton13 = new MaterialSkin.Controls.MaterialButton();
            materialButton17 = new MaterialSkin.Controls.MaterialButton();
            materialButton22 = new MaterialSkin.Controls.MaterialButton();
            materialButton14 = new MaterialSkin.Controls.MaterialButton();
            materialButton21 = new MaterialSkin.Controls.MaterialButton();
            materialButton16 = new MaterialSkin.Controls.MaterialButton();
            materialButton20 = new MaterialSkin.Controls.MaterialButton();
            materialButton15 = new MaterialSkin.Controls.MaterialButton();
            panel2 = new Panel();
            materialButton4 = new MaterialSkin.Controls.MaterialButton();
            materialButton3 = new MaterialSkin.Controls.MaterialButton();
            materialButton2 = new MaterialSkin.Controls.MaterialButton();
            materialButton1 = new MaterialSkin.Controls.MaterialButton();
            label1 = new Label();
            panel1.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            panel6.SuspendLayout();
            panel5.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(panel3);
            panel1.Controls.Add(panel4);
            panel1.Controls.Add(panel6);
            panel1.Controls.Add(panel5);
            panel1.Controls.Add(panel2);
            panel1.Location = new Point(-18, 22);
            panel1.Name = "panel1";
            panel1.Size = new Size(800, 549);
            panel1.TabIndex = 0;
            // 
            // panel3
            // 
            panel3.BorderStyle = BorderStyle.FixedSingle;
            panel3.Controls.Add(saveCheckpointSave);
            panel3.Controls.Add(savePresetPreset);
            panel3.Controls.Add(loadCheckpointSave);
            panel3.Controls.Add(loadPresetPreset);
            panel3.Controls.Add(materialButton6);
            panel3.Controls.Add(saveCheckpoint);
            panel3.Controls.Add(loadCheckpoint);
            panel3.Controls.Add(materialButton5);
            panel3.Location = new Point(410, 9);
            panel3.Name = "panel3";
            panel3.Size = new Size(378, 236);
            panel3.TabIndex = 2;
            // 
            // saveCheckpointSave
            // 
            saveCheckpointSave.AutoResize = false;
            saveCheckpointSave.BackColor = Color.FromArgb(255, 255, 255);
            saveCheckpointSave.Depth = 0;
            saveCheckpointSave.DrawMode = DrawMode.OwnerDrawVariable;
            saveCheckpointSave.DropDownHeight = 174;
            saveCheckpointSave.DropDownStyle = ComboBoxStyle.DropDownList;
            saveCheckpointSave.DropDownWidth = 121;
            saveCheckpointSave.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Bold, GraphicsUnit.Pixel);
            saveCheckpointSave.ForeColor = Color.FromArgb(222, 0, 0, 0);
            saveCheckpointSave.FormattingEnabled = true;
            saveCheckpointSave.IntegralHeight = false;
            saveCheckpointSave.ItemHeight = 43;
            saveCheckpointSave.Items.AddRange(new object[] { "Save 1", "Save 2", "Save 3", "Save 4" });
            saveCheckpointSave.Location = new Point(218, 129);
            saveCheckpointSave.MaxDropDownItems = 4;
            saveCheckpointSave.MouseState = MaterialSkin.MouseState.OUT;
            saveCheckpointSave.Name = "saveCheckpointSave";
            saveCheckpointSave.Size = new Size(121, 49);
            saveCheckpointSave.StartIndex = 0;
            saveCheckpointSave.TabIndex = 2;
            // 
            // savePresetPreset
            // 
            savePresetPreset.AutoResize = false;
            savePresetPreset.BackColor = Color.FromArgb(255, 255, 255);
            savePresetPreset.Depth = 0;
            savePresetPreset.DrawMode = DrawMode.OwnerDrawVariable;
            savePresetPreset.DropDownHeight = 174;
            savePresetPreset.DropDownStyle = ComboBoxStyle.DropDownList;
            savePresetPreset.DropDownWidth = 121;
            savePresetPreset.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Bold, GraphicsUnit.Pixel);
            savePresetPreset.ForeColor = Color.FromArgb(222, 0, 0, 0);
            savePresetPreset.FormattingEnabled = true;
            savePresetPreset.IntegralHeight = false;
            savePresetPreset.ItemHeight = 43;
            savePresetPreset.Items.AddRange(new object[] { "Preset 1", "Preset 2", "Preset 3", "Preset 4", "Preset 5", "Preset 6", "Preset 7", "Preset 8", "Preset 9" });
            savePresetPreset.Location = new Point(218, 13);
            savePresetPreset.MaxDropDownItems = 4;
            savePresetPreset.MouseState = MaterialSkin.MouseState.OUT;
            savePresetPreset.Name = "savePresetPreset";
            savePresetPreset.Size = new Size(121, 49);
            savePresetPreset.StartIndex = 0;
            savePresetPreset.TabIndex = 2;
            // 
            // loadCheckpointSave
            // 
            loadCheckpointSave.AutoResize = false;
            loadCheckpointSave.BackColor = Color.FromArgb(255, 255, 255);
            loadCheckpointSave.Depth = 0;
            loadCheckpointSave.DrawMode = DrawMode.OwnerDrawVariable;
            loadCheckpointSave.DropDownHeight = 174;
            loadCheckpointSave.DropDownStyle = ComboBoxStyle.DropDownList;
            loadCheckpointSave.DropDownWidth = 121;
            loadCheckpointSave.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            loadCheckpointSave.ForeColor = Color.FromArgb(222, 0, 0, 0);
            loadCheckpointSave.FormattingEnabled = true;
            loadCheckpointSave.IntegralHeight = false;
            loadCheckpointSave.ItemHeight = 43;
            loadCheckpointSave.Items.AddRange(new object[] { "Save 1", "Save 2", "Save 3", "Save 4" });
            loadCheckpointSave.Location = new Point(33, 129);
            loadCheckpointSave.MaxDropDownItems = 4;
            loadCheckpointSave.MouseState = MaterialSkin.MouseState.OUT;
            loadCheckpointSave.Name = "loadCheckpointSave";
            loadCheckpointSave.Size = new Size(121, 49);
            loadCheckpointSave.StartIndex = 0;
            loadCheckpointSave.TabIndex = 2;
            // 
            // loadPresetPreset
            // 
            loadPresetPreset.AutoResize = false;
            loadPresetPreset.BackColor = Color.FromArgb(255, 255, 255);
            loadPresetPreset.Depth = 0;
            loadPresetPreset.DrawMode = DrawMode.OwnerDrawVariable;
            loadPresetPreset.DropDownHeight = 174;
            loadPresetPreset.DropDownStyle = ComboBoxStyle.DropDownList;
            loadPresetPreset.DropDownWidth = 121;
            loadPresetPreset.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Bold, GraphicsUnit.Pixel);
            loadPresetPreset.ForeColor = Color.FromArgb(222, 0, 0, 0);
            loadPresetPreset.FormattingEnabled = true;
            loadPresetPreset.IntegralHeight = false;
            loadPresetPreset.ItemHeight = 43;
            loadPresetPreset.Items.AddRange(new object[] { "Preset 1", "Preset 2", "Preset 3", "Preset 4", "Preset 5", "Preset 6", "Preset 7", "Preset 8", "Preset 9" });
            loadPresetPreset.Location = new Point(33, 13);
            loadPresetPreset.MaxDropDownItems = 4;
            loadPresetPreset.MouseState = MaterialSkin.MouseState.OUT;
            loadPresetPreset.Name = "loadPresetPreset";
            loadPresetPreset.Size = new Size(121, 49);
            loadPresetPreset.StartIndex = 0;
            loadPresetPreset.TabIndex = 2;
            // 
            // materialButton6
            // 
            materialButton6.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton6.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton6.Depth = 0;
            materialButton6.HighEmphasis = true;
            materialButton6.Icon = null;
            materialButton6.Location = new Point(204, 71);
            materialButton6.Margin = new Padding(4, 6, 4, 6);
            materialButton6.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton6.Name = "materialButton6";
            materialButton6.NoAccentTextColor = Color.Empty;
            materialButton6.Size = new Size(114, 36);
            materialButton6.TabIndex = 1;
            materialButton6.Text = "Save Preset";
            materialButton6.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton6.UseAccentColor = false;
            materialButton6.UseVisualStyleBackColor = true;
            materialButton6.Click += savePreset_Click;
            // 
            // saveCheckpoint
            // 
            saveCheckpoint.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            saveCheckpoint.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            saveCheckpoint.Depth = 0;
            saveCheckpoint.HighEmphasis = true;
            saveCheckpoint.Icon = null;
            saveCheckpoint.Location = new Point(204, 187);
            saveCheckpoint.Margin = new Padding(4, 6, 4, 6);
            saveCheckpoint.MouseState = MaterialSkin.MouseState.HOVER;
            saveCheckpoint.Name = "saveCheckpoint";
            saveCheckpoint.NoAccentTextColor = Color.Empty;
            saveCheckpoint.Size = new Size(152, 36);
            saveCheckpoint.TabIndex = 1;
            saveCheckpoint.Text = "Save Checkpoint";
            saveCheckpoint.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            saveCheckpoint.UseAccentColor = false;
            saveCheckpoint.UseVisualStyleBackColor = true;
            saveCheckpoint.Click += saveCheckpoint_Click_1;
            // 
            // loadCheckpoint
            // 
            loadCheckpoint.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            loadCheckpoint.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            loadCheckpoint.Depth = 0;
            loadCheckpoint.HighEmphasis = true;
            loadCheckpoint.Icon = null;
            loadCheckpoint.Location = new Point(17, 187);
            loadCheckpoint.Margin = new Padding(4, 6, 4, 6);
            loadCheckpoint.MouseState = MaterialSkin.MouseState.HOVER;
            loadCheckpoint.Name = "loadCheckpoint";
            loadCheckpoint.NoAccentTextColor = Color.Empty;
            loadCheckpoint.Size = new Size(153, 36);
            loadCheckpoint.TabIndex = 1;
            loadCheckpoint.Text = "Load Checkpoint";
            loadCheckpoint.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            loadCheckpoint.UseAccentColor = false;
            loadCheckpoint.UseVisualStyleBackColor = true;
            loadCheckpoint.Click += loadCheckpoint_Click_1;
            // 
            // materialButton5
            // 
            materialButton5.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton5.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton5.Depth = 0;
            materialButton5.HighEmphasis = true;
            materialButton5.Icon = null;
            materialButton5.Location = new Point(17, 71);
            materialButton5.Margin = new Padding(4, 6, 4, 6);
            materialButton5.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton5.Name = "materialButton5";
            materialButton5.NoAccentTextColor = Color.Empty;
            materialButton5.Size = new Size(116, 36);
            materialButton5.TabIndex = 1;
            materialButton5.Text = "Load Preset";
            materialButton5.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton5.UseAccentColor = false;
            materialButton5.UseVisualStyleBackColor = true;
            materialButton5.Click += loadPreset_Click;
            // 
            // panel4
            // 
            panel4.BorderStyle = BorderStyle.FixedSingle;
            panel4.Controls.Add(materialButton11);
            panel4.Controls.Add(materialButton10);
            panel4.Controls.Add(materialButton9);
            panel4.Location = new Point(218, 9);
            panel4.Name = "panel4";
            panel4.Size = new Size(186, 236);
            panel4.TabIndex = 0;
            // 
            // materialButton11
            // 
            materialButton11.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton11.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton11.Depth = 0;
            materialButton11.HighEmphasis = true;
            materialButton11.Icon = null;
            materialButton11.Location = new Point(13, 161);
            materialButton11.Margin = new Padding(4, 6, 4, 6);
            materialButton11.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton11.Name = "materialButton11";
            materialButton11.NoAccentTextColor = Color.Empty;
            materialButton11.Size = new Size(99, 36);
            materialButton11.TabIndex = 0;
            materialButton11.Text = "Add Saves";
            materialButton11.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton11.UseAccentColor = false;
            materialButton11.UseVisualStyleBackColor = true;
            materialButton11.Click += addSelected_Click;
            // 
            // materialButton10
            // 
            materialButton10.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton10.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton10.Depth = 0;
            materialButton10.HighEmphasis = true;
            materialButton10.Icon = null;
            materialButton10.Location = new Point(13, 98);
            materialButton10.Margin = new Padding(4, 6, 4, 6);
            materialButton10.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton10.Name = "materialButton10";
            materialButton10.NoAccentTextColor = Color.Empty;
            materialButton10.Size = new Size(122, 36);
            materialButton10.TabIndex = 0;
            materialButton10.Text = "Delete Saves";
            materialButton10.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton10.UseAccentColor = false;
            materialButton10.UseVisualStyleBackColor = true;
            materialButton10.Click += deleteExcept_Click;
            // 
            // materialButton9
            // 
            materialButton9.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton9.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton9.Depth = 0;
            materialButton9.HighEmphasis = true;
            materialButton9.Icon = null;
            materialButton9.Location = new Point(13, 38);
            materialButton9.Margin = new Padding(4, 6, 4, 6);
            materialButton9.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton9.Name = "materialButton9";
            materialButton9.NoAccentTextColor = Color.Empty;
            materialButton9.Size = new Size(141, 36);
            materialButton9.TabIndex = 0;
            materialButton9.Text = "Toggle Window";
            materialButton9.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton9.UseAccentColor = false;
            materialButton9.UseVisualStyleBackColor = true;
            materialButton9.Click += menu_Click;
            // 
            // panel6
            // 
            panel6.BorderStyle = BorderStyle.FixedSingle;
            panel6.Controls.Add(materialButton25);
            panel6.Controls.Add(materialButton23);
            panel6.Controls.Add(materialButton30);
            panel6.Controls.Add(materialButton31);
            panel6.Controls.Add(materialButton33);
            panel6.Controls.Add(materialButton34);
            panel6.Controls.Add(materialButton35);
            panel6.Controls.Add(materialButton37);
            panel6.Controls.Add(materialButton38);
            panel6.Controls.Add(materialButton39);
            panel6.Controls.Add(materialButton40);
            panel6.Controls.Add(materialButton41);
            panel6.Controls.Add(materialButton42);
            panel6.Controls.Add(materialButton43);
            panel6.Location = new Point(410, 251);
            panel6.Name = "panel6";
            panel6.Size = new Size(378, 289);
            panel6.TabIndex = 0;
            // 
            // materialButton25
            // 
            materialButton25.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton25.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton25.Depth = 0;
            materialButton25.HighEmphasis = true;
            materialButton25.Icon = null;
            materialButton25.Location = new Point(204, 240);
            materialButton25.Margin = new Padding(4, 6, 4, 6);
            materialButton25.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton25.Name = "materialButton25";
            materialButton25.NoAccentTextColor = Color.Empty;
            materialButton25.Size = new Size(134, 36);
            materialButton25.TabIndex = 2;
            materialButton25.Text = "Coming Soon...";
            materialButton25.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton25.UseAccentColor = false;
            materialButton25.UseVisualStyleBackColor = true;
            // 
            // materialButton23
            // 
            materialButton23.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton23.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton23.Depth = 0;
            materialButton23.HighEmphasis = true;
            materialButton23.Icon = null;
            materialButton23.Location = new Point(12, 240);
            materialButton23.Margin = new Padding(4, 6, 4, 6);
            materialButton23.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton23.Name = "materialButton23";
            materialButton23.NoAccentTextColor = Color.Empty;
            materialButton23.Size = new Size(134, 36);
            materialButton23.TabIndex = 2;
            materialButton23.Text = "Coming Soon...";
            materialButton23.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton23.UseAccentColor = false;
            materialButton23.UseVisualStyleBackColor = true;
            // 
            // materialButton30
            // 
            materialButton30.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton30.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton30.Depth = 0;
            materialButton30.HighEmphasis = true;
            materialButton30.Icon = null;
            materialButton30.Location = new Point(204, 123);
            materialButton30.Margin = new Padding(4, 6, 4, 6);
            materialButton30.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton30.Name = "materialButton30";
            materialButton30.NoAccentTextColor = Color.Empty;
            materialButton30.Size = new Size(127, 36);
            materialButton30.TabIndex = 1;
            materialButton30.Text = "Post Process";
            materialButton30.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton30.UseAccentColor = false;
            materialButton30.UseVisualStyleBackColor = true;
            materialButton30.Click += postProcess_Click;
            // 
            // materialButton31
            // 
            materialButton31.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton31.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton31.Depth = 0;
            materialButton31.HighEmphasis = true;
            materialButton31.Icon = null;
            materialButton31.Location = new Point(12, 123);
            materialButton31.Margin = new Padding(4, 6, 4, 6);
            materialButton31.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton31.Name = "materialButton31";
            materialButton31.NoAccentTextColor = Color.Empty;
            materialButton31.Size = new Size(135, 36);
            materialButton31.TabIndex = 1;
            materialButton31.Text = "Show Volumes";
            materialButton31.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton31.UseAccentColor = false;
            materialButton31.UseVisualStyleBackColor = true;
            materialButton31.Click += showVolumes_Click;
            // 
            // materialButton33
            // 
            materialButton33.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton33.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton33.Depth = 0;
            materialButton33.HighEmphasis = true;
            materialButton33.Icon = null;
            materialButton33.Location = new Point(204, 201);
            materialButton33.Margin = new Padding(4, 6, 4, 6);
            materialButton33.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton33.Name = "materialButton33";
            materialButton33.NoAccentTextColor = Color.Empty;
            materialButton33.Size = new Size(86, 36);
            materialButton33.TabIndex = 1;
            materialButton33.Text = "AI Debug";
            materialButton33.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton33.UseAccentColor = false;
            materialButton33.UseVisualStyleBackColor = true;
            materialButton33.Click += ai_Click;
            // 
            // materialButton34
            // 
            materialButton34.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton34.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton34.Depth = 0;
            materialButton34.HighEmphasis = true;
            materialButton34.Icon = null;
            materialButton34.Location = new Point(204, 84);
            materialButton34.Margin = new Padding(4, 6, 4, 6);
            materialButton34.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton34.Name = "materialButton34";
            materialButton34.NoAccentTextColor = Color.Empty;
            materialButton34.Size = new Size(115, 36);
            materialButton34.TabIndex = 1;
            materialButton34.Text = "Show Paths";
            materialButton34.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton34.UseAccentColor = false;
            materialButton34.UseVisualStyleBackColor = true;
            materialButton34.Click += showPaths_Click;
            // 
            // materialButton35
            // 
            materialButton35.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton35.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton35.Depth = 0;
            materialButton35.HighEmphasis = true;
            materialButton35.Icon = null;
            materialButton35.Location = new Point(12, 84);
            materialButton35.Margin = new Padding(4, 6, 4, 6);
            materialButton35.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton35.Name = "materialButton35";
            materialButton35.NoAccentTextColor = Color.Empty;
            materialButton35.Size = new Size(115, 36);
            materialButton35.TabIndex = 1;
            materialButton35.Text = "Show Debug";
            materialButton35.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton35.UseAccentColor = false;
            materialButton35.UseVisualStyleBackColor = true;
            materialButton35.Click += showDebug_Click;
            // 
            // materialButton37
            // 
            materialButton37.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton37.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton37.Depth = 0;
            materialButton37.HighEmphasis = true;
            materialButton37.Icon = null;
            materialButton37.Location = new Point(12, 201);
            materialButton37.Margin = new Padding(4, 6, 4, 6);
            materialButton37.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton37.Name = "materialButton37";
            materialButton37.NoAccentTextColor = Color.Empty;
            materialButton37.Size = new Size(111, 36);
            materialButton37.TabIndex = 1;
            materialButton37.Text = "Mesh Edges";
            materialButton37.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton37.UseAccentColor = false;
            materialButton37.UseVisualStyleBackColor = true;
            materialButton37.Click += meshEdges_Click;
            // 
            // materialButton38
            // 
            materialButton38.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton38.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton38.Depth = 0;
            materialButton38.HighEmphasis = true;
            materialButton38.Icon = null;
            materialButton38.Location = new Point(204, 45);
            materialButton38.Margin = new Padding(4, 6, 4, 6);
            materialButton38.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton38.Name = "materialButton38";
            materialButton38.NoAccentTextColor = Color.Empty;
            materialButton38.Size = new Size(133, 36);
            materialButton38.TabIndex = 1;
            materialButton38.Text = "Static Meshes";
            materialButton38.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton38.UseAccentColor = false;
            materialButton38.UseVisualStyleBackColor = true;
            materialButton38.Click += staticMeshes_Click;
            // 
            // materialButton39
            // 
            materialButton39.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton39.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton39.Depth = 0;
            materialButton39.HighEmphasis = true;
            materialButton39.Icon = null;
            materialButton39.Location = new Point(12, 45);
            materialButton39.Margin = new Padding(4, 6, 4, 6);
            materialButton39.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton39.Name = "materialButton39";
            materialButton39.NoAccentTextColor = Color.Empty;
            materialButton39.Size = new Size(112, 36);
            materialButton39.TabIndex = 1;
            materialButton39.Text = "Stat Levels";
            materialButton39.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton39.UseAccentColor = false;
            materialButton39.UseVisualStyleBackColor = true;
            materialButton39.Click += statLevels_Click;
            // 
            // materialButton40
            // 
            materialButton40.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton40.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton40.Depth = 0;
            materialButton40.HighEmphasis = true;
            materialButton40.Icon = null;
            materialButton40.Location = new Point(204, 162);
            materialButton40.Margin = new Padding(4, 6, 4, 6);
            materialButton40.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton40.Name = "materialButton40";
            materialButton40.NoAccentTextColor = Color.Empty;
            materialButton40.Size = new Size(155, 36);
            materialButton40.TabIndex = 0;
            materialButton40.Text = "Levelcoloration";
            materialButton40.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton40.UseAccentColor = false;
            materialButton40.UseVisualStyleBackColor = true;
            materialButton40.Click += levelColoration_Click;
            // 
            // materialButton41
            // 
            materialButton41.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton41.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton41.Depth = 0;
            materialButton41.HighEmphasis = true;
            materialButton41.Icon = null;
            materialButton41.Location = new Point(12, 162);
            materialButton41.Margin = new Padding(4, 6, 4, 6);
            materialButton41.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton41.Name = "materialButton41";
            materialButton41.NoAccentTextColor = Color.Empty;
            materialButton41.Size = new Size(96, 36);
            materialButton41.TabIndex = 0;
            materialButton41.Text = "Show Fog";
            materialButton41.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton41.UseAccentColor = false;
            materialButton41.UseVisualStyleBackColor = true;
            materialButton41.Click += showFog_Click;
            // 
            // materialButton42
            // 
            materialButton42.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton42.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton42.Depth = 0;
            materialButton42.HighEmphasis = true;
            materialButton42.Icon = null;
            materialButton42.Location = new Point(204, 6);
            materialButton42.Margin = new Padding(4, 6, 4, 6);
            materialButton42.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton42.Name = "materialButton42";
            materialButton42.NoAccentTextColor = Color.Empty;
            materialButton42.Size = new Size(126, 36);
            materialButton42.TabIndex = 0;
            materialButton42.Text = "Show Bounds";
            materialButton42.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton42.UseAccentColor = false;
            materialButton42.UseVisualStyleBackColor = true;
            materialButton42.Click += showBounds_Click;
            // 
            // materialButton43
            // 
            materialButton43.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton43.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton43.Depth = 0;
            materialButton43.HighEmphasis = true;
            materialButton43.Icon = null;
            materialButton43.Location = new Point(12, 6);
            materialButton43.Margin = new Padding(4, 6, 4, 6);
            materialButton43.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton43.Name = "materialButton43";
            materialButton43.NoAccentTextColor = Color.Empty;
            materialButton43.Size = new Size(141, 36);
            materialButton43.TabIndex = 0;
            materialButton43.Text = "Show Collision";
            materialButton43.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton43.UseAccentColor = false;
            materialButton43.UseVisualStyleBackColor = true;
            materialButton43.Click += showCollision_Click;
            // 
            // panel5
            // 
            panel5.BorderStyle = BorderStyle.FixedSingle;
            panel5.Controls.Add(materialButton19);
            panel5.Controls.Add(materialButton29);
            panel5.Controls.Add(materialButton26);
            panel5.Controls.Add(materialButton12);
            panel5.Controls.Add(materialButton18);
            panel5.Controls.Add(materialButton24);
            panel5.Controls.Add(materialButton13);
            panel5.Controls.Add(materialButton17);
            panel5.Controls.Add(materialButton22);
            panel5.Controls.Add(materialButton14);
            panel5.Controls.Add(materialButton21);
            panel5.Controls.Add(materialButton16);
            panel5.Controls.Add(materialButton20);
            panel5.Controls.Add(materialButton15);
            panel5.Location = new Point(26, 251);
            panel5.Name = "panel5";
            panel5.Size = new Size(378, 289);
            panel5.TabIndex = 0;
            // 
            // materialButton19
            // 
            materialButton19.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton19.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton19.Depth = 0;
            materialButton19.HighEmphasis = true;
            materialButton19.Icon = null;
            materialButton19.Location = new Point(205, 201);
            materialButton19.Margin = new Padding(4, 6, 4, 6);
            materialButton19.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton19.Name = "materialButton19";
            materialButton19.NoAccentTextColor = Color.Empty;
            materialButton19.Size = new Size(172, 36);
            materialButton19.TabIndex = 1;
            materialButton19.Text = "Reset Collactibles";
            materialButton19.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton19.UseAccentColor = false;
            materialButton19.UseVisualStyleBackColor = true;
            materialButton19.Click += removeCollactibles_Click;
            // 
            // materialButton29
            // 
            materialButton29.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton29.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton29.Depth = 0;
            materialButton29.HighEmphasis = true;
            materialButton29.Icon = null;
            materialButton29.Location = new Point(205, 240);
            materialButton29.Margin = new Padding(4, 6, 4, 6);
            materialButton29.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton29.Name = "materialButton29";
            materialButton29.NoAccentTextColor = Color.Empty;
            materialButton29.Size = new Size(88, 36);
            materialButton29.TabIndex = 1;
            materialButton29.Text = "Stat FPS";
            materialButton29.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton29.UseAccentColor = false;
            materialButton29.UseVisualStyleBackColor = true;
            materialButton29.Click += statFPS_Click;
            // 
            // materialButton26
            // 
            materialButton26.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton26.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton26.Depth = 0;
            materialButton26.HighEmphasis = true;
            materialButton26.Icon = null;
            materialButton26.Location = new Point(205, 123);
            materialButton26.Margin = new Padding(4, 6, 4, 6);
            materialButton26.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton26.Name = "materialButton26";
            materialButton26.NoAccentTextColor = Color.Empty;
            materialButton26.Size = new Size(186, 36);
            materialButton26.TabIndex = 1;
            materialButton26.Text = "Load Speedrun Start";
            materialButton26.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton26.UseAccentColor = false;
            materialButton26.UseVisualStyleBackColor = true;
            materialButton26.Click += loadCheckpoint_Click;
            // 
            // materialButton12
            // 
            materialButton12.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton12.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton12.Depth = 0;
            materialButton12.HighEmphasis = true;
            materialButton12.Icon = null;
            materialButton12.Location = new Point(12, 123);
            materialButton12.Margin = new Padding(4, 6, 4, 6);
            materialButton12.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton12.Name = "materialButton12";
            materialButton12.NoAccentTextColor = Color.Empty;
            materialButton12.Size = new Size(95, 36);
            materialButton12.TabIndex = 1;
            materialButton12.Text = "Rage Quit";
            materialButton12.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton12.UseAccentColor = false;
            materialButton12.UseVisualStyleBackColor = true;
            materialButton12.Click += exit_Click;
            // 
            // materialButton18
            // 
            materialButton18.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton18.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton18.Depth = 0;
            materialButton18.HighEmphasis = true;
            materialButton18.Icon = null;
            materialButton18.Location = new Point(12, 201);
            materialButton18.Margin = new Padding(4, 6, 4, 6);
            materialButton18.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton18.Name = "materialButton18";
            materialButton18.NoAccentTextColor = Color.Empty;
            materialButton18.Size = new Size(119, 36);
            materialButton18.TabIndex = 1;
            materialButton18.Text = "Reset World";
            materialButton18.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton18.UseAccentColor = false;
            materialButton18.UseVisualStyleBackColor = true;
            materialButton18.Click += rsw_Click;
            // 
            // materialButton24
            // 
            materialButton24.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton24.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton24.Depth = 0;
            materialButton24.HighEmphasis = true;
            materialButton24.Icon = null;
            materialButton24.Location = new Point(205, 84);
            materialButton24.Margin = new Padding(4, 6, 4, 6);
            materialButton24.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton24.Name = "materialButton24";
            materialButton24.NoAccentTextColor = Color.Empty;
            materialButton24.Size = new Size(174, 36);
            materialButton24.TabIndex = 1;
            materialButton24.Text = "Set Speedrun Start";
            materialButton24.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton24.UseAccentColor = false;
            materialButton24.UseVisualStyleBackColor = true;
            materialButton24.Click += saveCheckpoint_Click;
            // 
            // materialButton13
            // 
            materialButton13.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton13.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton13.Depth = 0;
            materialButton13.HighEmphasis = true;
            materialButton13.Icon = null;
            materialButton13.Location = new Point(12, 84);
            materialButton13.Margin = new Padding(4, 6, 4, 6);
            materialButton13.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton13.Name = "materialButton13";
            materialButton13.NoAccentTextColor = Color.Empty;
            materialButton13.Size = new Size(166, 36);
            materialButton13.TabIndex = 1;
            materialButton13.Text = "GameplayMarkers";
            materialButton13.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton13.UseAccentColor = false;
            materialButton13.UseVisualStyleBackColor = true;
            materialButton13.Click += gameMarkers_Click;
            // 
            // materialButton17
            // 
            materialButton17.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton17.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton17.Depth = 0;
            materialButton17.HighEmphasis = true;
            materialButton17.Icon = null;
            materialButton17.Location = new Point(12, 240);
            materialButton17.Margin = new Padding(4, 6, 4, 6);
            materialButton17.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton17.Name = "materialButton17";
            materialButton17.NoAccentTextColor = Color.Empty;
            materialButton17.Size = new Size(112, 36);
            materialButton17.TabIndex = 1;
            materialButton17.Text = "Max Gamma";
            materialButton17.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton17.UseAccentColor = false;
            materialButton17.UseVisualStyleBackColor = true;
            materialButton17.Click += maxGamma_Click;
            // 
            // materialButton22
            // 
            materialButton22.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton22.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton22.Depth = 0;
            materialButton22.HighEmphasis = true;
            materialButton22.Icon = null;
            materialButton22.Location = new Point(205, 45);
            materialButton22.Margin = new Padding(4, 6, 4, 6);
            materialButton22.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton22.Name = "materialButton22";
            materialButton22.NoAccentTextColor = Color.Empty;
            materialButton22.Size = new Size(110, 36);
            materialButton22.TabIndex = 1;
            materialButton22.Text = "TP Freecam";
            materialButton22.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton22.UseAccentColor = false;
            materialButton22.UseVisualStyleBackColor = true;
            materialButton22.Click += tptofreecamBtn_Click;
            // 
            // materialButton14
            // 
            materialButton14.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton14.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton14.Depth = 0;
            materialButton14.HighEmphasis = true;
            materialButton14.Icon = null;
            materialButton14.Location = new Point(12, 45);
            materialButton14.Margin = new Padding(4, 6, 4, 6);
            materialButton14.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton14.Name = "materialButton14";
            materialButton14.NoAccentTextColor = Color.Empty;
            materialButton14.Size = new Size(108, 36);
            materialButton14.TabIndex = 1;
            materialButton14.Text = "PlayerInfo";
            materialButton14.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton14.UseAccentColor = false;
            materialButton14.UseVisualStyleBackColor = true;
            materialButton14.Click += playerInfo_Click;
            // 
            // materialButton21
            // 
            materialButton21.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton21.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton21.Depth = 0;
            materialButton21.HighEmphasis = true;
            materialButton21.Icon = null;
            materialButton21.Location = new Point(205, 162);
            materialButton21.Margin = new Padding(4, 6, 4, 6);
            materialButton21.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton21.Name = "materialButton21";
            materialButton21.NoAccentTextColor = Color.Empty;
            materialButton21.Size = new Size(117, 36);
            materialButton21.TabIndex = 0;
            materialButton21.Text = "Reload Save";
            materialButton21.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton21.UseAccentColor = false;
            materialButton21.UseVisualStyleBackColor = true;
            materialButton21.Click += reloadCheckpoint_Click;
            // 
            // materialButton16
            // 
            materialButton16.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton16.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton16.Depth = 0;
            materialButton16.HighEmphasis = true;
            materialButton16.Icon = null;
            materialButton16.Location = new Point(12, 162);
            materialButton16.Margin = new Padding(4, 6, 4, 6);
            materialButton16.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton16.Name = "materialButton16";
            materialButton16.NoAccentTextColor = Color.Empty;
            materialButton16.Size = new Size(157, 36);
            materialButton16.TabIndex = 0;
            materialButton16.Text = "Insane Difficulty";
            materialButton16.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton16.UseAccentColor = false;
            materialButton16.UseVisualStyleBackColor = true;
            materialButton16.Click += insaneDifficulty_Click;
            // 
            // materialButton20
            // 
            materialButton20.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton20.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton20.Depth = 0;
            materialButton20.HighEmphasis = true;
            materialButton20.Icon = null;
            materialButton20.Location = new Point(205, 6);
            materialButton20.Margin = new Padding(4, 6, 4, 6);
            materialButton20.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton20.Name = "materialButton20";
            materialButton20.NoAccentTextColor = Color.Empty;
            materialButton20.Size = new Size(88, 36);
            materialButton20.TabIndex = 0;
            materialButton20.Text = "Freecam";
            materialButton20.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton20.UseAccentColor = false;
            materialButton20.UseVisualStyleBackColor = true;
            materialButton20.Click += freeCam_Click;
            // 
            // materialButton15
            // 
            materialButton15.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton15.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton15.Depth = 0;
            materialButton15.HighEmphasis = true;
            materialButton15.Icon = null;
            materialButton15.Location = new Point(12, 6);
            materialButton15.Margin = new Padding(4, 6, 4, 6);
            materialButton15.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton15.Name = "materialButton15";
            materialButton15.NoAccentTextColor = Color.Empty;
            materialButton15.Size = new Size(107, 36);
            materialButton15.TabIndex = 0;
            materialButton15.Text = "GameSpeed";
            materialButton15.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton15.UseAccentColor = false;
            materialButton15.UseVisualStyleBackColor = true;
            materialButton15.Click += gameSpeed_Click;
            // 
            // panel2
            // 
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(materialButton4);
            panel2.Controls.Add(materialButton3);
            panel2.Controls.Add(materialButton2);
            panel2.Controls.Add(materialButton1);
            panel2.Location = new Point(26, 9);
            panel2.Name = "panel2";
            panel2.Size = new Size(186, 236);
            panel2.TabIndex = 0;
            // 
            // materialButton4
            // 
            materialButton4.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton4.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton4.Depth = 0;
            materialButton4.HighEmphasis = true;
            materialButton4.Icon = null;
            materialButton4.Location = new Point(12, 187);
            materialButton4.Margin = new Padding(4, 6, 4, 6);
            materialButton4.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton4.Name = "materialButton4";
            materialButton4.NoAccentTextColor = Color.Empty;
            materialButton4.Size = new Size(136, 36);
            materialButton4.TabIndex = 1;
            materialButton4.Text = "Shimmy Hitbox";
            materialButton4.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton4.UseAccentColor = false;
            materialButton4.UseVisualStyleBackColor = true;
            materialButton4.Click += HitBoxShimmy;
            // 
            // materialButton3
            // 
            materialButton3.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton3.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton3.Depth = 0;
            materialButton3.HighEmphasis = true;
            materialButton3.Icon = null;
            materialButton3.Location = new Point(12, 129);
            materialButton3.Margin = new Padding(4, 6, 4, 6);
            materialButton3.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton3.Name = "materialButton3";
            materialButton3.NoAccentTextColor = Color.Empty;
            materialButton3.Size = new Size(117, 36);
            materialButton3.TabIndex = 1;
            materialButton3.Text = "Door Hitbox";
            materialButton3.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton3.UseAccentColor = false;
            materialButton3.UseVisualStyleBackColor = true;
            materialButton3.Click += HitBoxDoor;
            // 
            // materialButton2
            // 
            materialButton2.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton2.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton2.Depth = 0;
            materialButton2.HighEmphasis = true;
            materialButton2.Icon = null;
            materialButton2.Location = new Point(12, 71);
            materialButton2.Margin = new Padding(4, 6, 4, 6);
            materialButton2.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton2.Name = "materialButton2";
            materialButton2.NoAccentTextColor = Color.Empty;
            materialButton2.Size = new Size(123, 36);
            materialButton2.TabIndex = 1;
            materialButton2.Text = "Vault Hitbox";
            materialButton2.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton2.UseAccentColor = false;
            materialButton2.UseVisualStyleBackColor = true;
            materialButton2.Click += HitBoxVault;
            // 
            // materialButton1
            // 
            materialButton1.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton1.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton1.Depth = 0;
            materialButton1.HighEmphasis = true;
            materialButton1.Icon = null;
            materialButton1.Location = new Point(12, 13);
            materialButton1.Margin = new Padding(4, 6, 4, 6);
            materialButton1.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton1.Name = "materialButton1";
            materialButton1.NoAccentTextColor = Color.Empty;
            materialButton1.Size = new Size(138, 36);
            materialButton1.TabIndex = 0;
            materialButton1.Text = "Normal Hitbox";
            materialButton1.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton1.UseAccentColor = false;
            materialButton1.UseVisualStyleBackColor = true;
            materialButton1.Click += HitBoxNormal;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.ForeColor = SystemColors.ButtonFace;
            label1.Location = new Point(32, 4);
            label1.Name = "label1";
            label1.Size = new Size(37, 15);
            label1.TabIndex = 1;
            label1.Text = "Mods";
            // 
            // mods
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1038, 1197);
            Controls.Add(label1);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "mods";
            Sizable = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Mods";
            TopMost = true;
            Load += mods_Load;
            panel1.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private ToolTip toolTip1;
        private Panel panel1;
        private Label label1;
        private Panel panel2;
        private MaterialSkin.Controls.MaterialButton materialButton1;
        private MaterialSkin.Controls.MaterialButton materialButton4;
        private MaterialSkin.Controls.MaterialButton materialButton3;
        private MaterialSkin.Controls.MaterialButton materialButton2;
        private Panel panel3;
        private MaterialSkin.Controls.MaterialButton materialButton5;
        private MaterialSkin.Controls.MaterialButton materialButton6;
        private MaterialSkin.Controls.MaterialComboBox savePresetPreset;
        private MaterialSkin.Controls.MaterialComboBox loadPresetPreset;
        private MaterialSkin.Controls.MaterialComboBox saveCheckpointSave;
        private MaterialSkin.Controls.MaterialComboBox loadCheckpointSave;
        private MaterialSkin.Controls.MaterialButton saveCheckpoint;
        private MaterialSkin.Controls.MaterialButton loadCheckpoint;
        private Panel panel4;
        private MaterialSkin.Controls.MaterialButton materialButton9;
        private MaterialSkin.Controls.MaterialButton materialButton11;
        private MaterialSkin.Controls.MaterialButton materialButton10;
        private Panel panel5;
        private MaterialSkin.Controls.MaterialButton materialButton12;
        private MaterialSkin.Controls.MaterialButton materialButton13;
        private MaterialSkin.Controls.MaterialButton materialButton14;
        private MaterialSkin.Controls.MaterialButton materialButton15;
        private MaterialSkin.Controls.MaterialButton materialButton19;
        private MaterialSkin.Controls.MaterialButton materialButton18;
        private MaterialSkin.Controls.MaterialButton materialButton17;
        private MaterialSkin.Controls.MaterialButton materialButton16;
        private MaterialSkin.Controls.MaterialButton materialButton26;
        private MaterialSkin.Controls.MaterialButton materialButton24;
        private MaterialSkin.Controls.MaterialButton materialButton22;
        private MaterialSkin.Controls.MaterialButton materialButton21;
        private MaterialSkin.Controls.MaterialButton materialButton20;
        private Panel panel6;
        private MaterialSkin.Controls.MaterialButton materialButton29;
        private MaterialSkin.Controls.MaterialButton materialButton30;
        private MaterialSkin.Controls.MaterialButton materialButton31;
        private MaterialSkin.Controls.MaterialButton materialButton33;
        private MaterialSkin.Controls.MaterialButton materialButton34;
        private MaterialSkin.Controls.MaterialButton materialButton35;
        private MaterialSkin.Controls.MaterialButton materialButton37;
        private MaterialSkin.Controls.MaterialButton materialButton38;
        private MaterialSkin.Controls.MaterialButton materialButton39;
        private MaterialSkin.Controls.MaterialButton materialButton40;
        private MaterialSkin.Controls.MaterialButton materialButton41;
        private MaterialSkin.Controls.MaterialButton materialButton42;
        private MaterialSkin.Controls.MaterialButton materialButton43;
        private MaterialSkin.Controls.MaterialButton materialButton25;
        private MaterialSkin.Controls.MaterialButton materialButton23;
    }
}