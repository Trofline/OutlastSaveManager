﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;

class Program
{
    [Flags]
    public enum ProcessAccessFlags : uint
    {
        All = 0x001F0FFF,
        VMOperation = 0x0008,
        VMRead = 0x0010,
        VMWrite = 0x0020,
    }

    [DllImport("kernel32.dll")]
    public static extern IntPtr OpenProcess(ProcessAccessFlags access, bool inheritHandle, int processId);

    [DllImport("kernel32.dll")]
    public static extern bool CloseHandle(IntPtr hObject);

    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, int nSize, out IntPtr lpNumberOfBytesWritten);

    static void Main()
    {
        const long BATTERY_OFFSET = 0xD5D0ED; // Offset aus Cheat Engine
        byte[] batteryFull = BitConverter.GetBytes(1.0f); // volle Batterie

        Console.WriteLine("Infinite Battery wird automatisch aktiv...");

        while (true)
        {
            Process[] procs = Process.GetProcessesByName("OLGame");
            if (procs.Length > 0)
            {
                Process proc = procs[0];
                IntPtr handle = OpenProcess(ProcessAccessFlags.All, false, proc.Id);
                if (handle != IntPtr.Zero)
                {
                    IntPtr targetAddr = proc.MainModule.BaseAddress + 0xD5D0ED;
                    WriteProcessMemory(handle, targetAddr, batteryFull, batteryFull.Length, out _);
                    CloseHandle(handle);
                }
            }

            Thread.Sleep(50); // alle 50ms schreiben
        }
    }
}
